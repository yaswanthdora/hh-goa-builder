# ⚡ Hacker House Goa 2026 — Builder Card Generator

A high-performance, mobile-responsive **Profile Frame & ID Card Generator** for
Hacker House Goa 2026. Upload a photo, pick a frame, tweak your details, and
export a crisp high-res PNG — all in the browser.

Built with **React + Vite + Tailwind CSS + HTML5 Canvas**, styled for the HH Goa
vibe: dark forest green, neon pink, soft cream, and a slate-dark backdrop.
Fully ready to deploy to **GitHub Pages**.

![stack](https://img.shields.io/badge/React-18-61dafb) ![stack](https://img.shields.io/badge/Vite-5-646cff) ![stack](https://img.shields.io/badge/Tailwind-3-38bdf8) ![stack](https://img.shields.io/badge/canvas-1080%C2%B2%20%2F%201200%C3%97630-ff007a)

---

## ✨ Features

- **File upload** — drag & drop or browse; supports `.png`, `.jpg`, `.jpeg`, and
  **`.heic`/`.heif`** photos converted **client-side** with `heic2any` (nothing
  ever leaves the device).
- **Canvas rendering engine** — fixed export resolutions:
  - **1080×1080** square avatar
  - **1200×630** ID card
- **Auto-center & crop** — photos are drawn with `object-fit: cover` logic, then
  you can **drag**, **zoom** (slider or scroll wheel), and fine-tune **X/Y pan**
  with live sliders.
- **Preset gallery** — eight curated card styles in one click, varying the accent
  color, name/mono fonts, background and frame artwork (ppf · poster · classic · sunset · minimal).
  The default **HH Goa PPF** preset mirrors the official web look: circular photo
  crop inside a yellow ring with curved text, the Devanagari **गोवा** stamp, and a
  builder-ID barcode. **Poster Goa** is the cream tropical-poster look from the
  HH Goa web — light background, forest-green serif text, sunburst, palms,
  postage stamps and a barcode band.
- **Customizer** — live accent & background color pickers, plus toggles to show/hide
  individual frame parts (badge, waves, tagline) on any preset.
- **Optional QR code** — client-side generated QR (`qrcode` lib) on the ID card
  that links to the live site; toggle it on/off from the customizer.
- **Frame overlay system** — layered SVG/PNG artwork on top of the photo, with
  sample **HH Goa 2026** frames included, plus the option to **upload your own
  overlay** (PNG/JPG/SVG/WEBP).
- **Live dynamic text** — Full Name, Role/Stack, and Builder Title rendered over
  the frame with neon glow, auto-shrinking to fit.
- **Instant download** — one click exports a high-res `hh-goa-builder.png`.
- **Copy to clipboard** — paste your card straight into chats (Chromium-based
  browsers).
- **Share to X** — opens `twitter.com/intent/tweet` pre-filled with
  `Just generated my HH Goa 2026 Builder Card! Check it out #FrameInGoa` plus a
  link to the live app.
- **GitHub Pages ready** — relative asset base, Actions deploy workflow, and a
  `gh-pages` script alternative.

## 🚀 Quick Start

```bash
npm install
npm run dev        # local dev server
npm run build      # production build → dist/
npm run preview    # preview the production build
```

## 📦 Deploy to GitHub Pages

### Option A — GitHub Actions (recommended)

1. Push this repo to GitHub (default branch `main`).
2. Go to **Settings → Pages** and set **Source → GitHub Actions**.
3. Push to `main` (or run the workflow manually) — the
   [`.github/workflows/deploy.yml`](.github/workflows/deploy.yml) workflow
   builds the app and deploys `dist/` automatically.

Your app will be live at `https://<username>.github.io/<repo>/`. Because
`vite.config.js` uses `base: './'`, all asset paths are relative and work under
any sub-path.

> Update `SITE_URL` in [`src/config.js`](src/config.js) to your real deployed
> URL so the **Share to X** intent points at the live app.

### Option B — gh-pages CLI

```bash
npm run deploy     # builds (predeploy) and publishes dist/ to gh-pages branch
```

Then in **Settings → Pages** set **Source → Deploy from a branch → gh-pages**.

## 🎨 Customization

| What | Where |
| --- | --- |
| Brand colors | `tailwind.config.js` + `PALETTE` in `src/lib/renderer.js` |
| Fonts | `index.html` (Google Fonts links) + `tailwind.config.js` |
| Card style presets | `src/presets.js` (accent, fonts, art variant, background) |
| Customizer overrides / toggles | `src/App.jsx` (`styleOverrides`, `toggles`) |
| Color helpers | `src/lib/color.js` (`lighten`, `darken`) |
| Frame artwork (SVG templates) | `src/assets/frames/*.svg` (ppf/poster/classic/sunset/minimal) — tokens `#FF007A`/`#FF5CA8` are replaced with the accent; wrap toggleable parts in `<g id="frame-badge">` / `frame-waves` / `frame-tagline` |
| Circular photo crop (PPF / Poster) | `SQUARE_CIRCLE` / `POSTER_SQUARE_CIRCLE` / `CARD_CIRCLE` + `CIRCLE_LAYOUTS` in `src/lib/renderer.js` (keep in sync with `ppf-*.svg` / `poster-*.svg`) |
| Light (poster) theme | `light: true` on a preset in `src/presets.js` — flips canvas text to forest-on-cream |
| Frame templating / caching | `src/lib/frames.js` |
| Text placement / sizes | `drawSquareText` / `drawCardText` in `src/lib/renderer.js` |
| QR code target & style | `SITE_URL` in `src/config.js`; placement in `drawQrChip` in `src/lib/renderer.js` |
| Photo region on ID card | `CARD_PHOTO_REGION` in `src/lib/renderer.js` (keep in sync with `frame-card.svg`) |
| Share text / site URL | `src/config.js` |
| Export filename | `handleDownload` in `src/App.jsx` |

**Swapping the frames:** add a new SVG template per format in
`src/assets/frames/` and register it in `TEMPLATES` inside `src/lib/frames.js`
(use the `#FF007A` / `#FF5CA8` color tokens so preset accents apply), then add a
preset that references it in `src/presets.js`. For the ID card format, keep the
photo region coordinates in sync so the photo sits behind the frame border.

**Adding a preset:** copy an entry in `src/presets.js` and tweak `accent`,
`accentSoft`, `nameFont`, `monoFont`, `art` and the `bgTop`/`bgBottom` gradient.
Font families are loaded via Google Fonts in `index.html` — add new families
there if you introduce one.

## 🗂 Project Structure

```
├── .github/workflows/deploy.yml   # GitHub Pages CI/CD
├── public/
│   ├── favicon.svg
│   └── .nojekyll                  # skip Jekyll processing on Pages
├── src/
│   ├── App.jsx                    # state, preview canvas, controls, actions
│   ├── main.jsx                   # React entry
│   ├── index.css                  # Tailwind + custom slider/canvas styles
│   ├── config.js                  # site URL, share text, defaults, limits
│   ├── presets.js                 # curated card styles (accent, fonts, art)
│   ├── assets/frames/             # HH Goa 2026 SVG frame templates (ppf/poster/classic/sunset/minimal)
│   ├── components/UploadZone.jsx  # drag & drop upload
│   └── lib/
│       ├── renderer.js            # canvas rendering engine
│       ├── frames.js              # accent injection + toggleable parts
│       └── color.js               # hex color helpers for the customizer
├── index.html
├── vite.config.js                 # base: './' for GitHub Pages
├── tailwind.config.js
└── postcss.config.js
```

## 🛡 Privacy

Everything runs client-side. Photos and HEIC conversions are processed entirely
in your browser — nothing is uploaded to any server.
