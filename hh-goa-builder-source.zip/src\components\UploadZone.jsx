import { useRef, useState } from 'react';

export default function UploadZone({ photo, busy, onFile, onRemove }) {
  const inputRef = useRef(null);
  const [dragOver, setDragOver] = useState(false);

  const openPicker = () => {
    if (!busy) inputRef.current?.click();
  };

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={openPicker}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') openPicker();
      }}
      onDragOver={(e) => {
        e.preventDefault();
        if (!busy) setDragOver(true);
      }}
      onDragLeave={() => setDragOver(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragOver(false);
        const file = e.dataTransfer?.files?.[0];
        if (file) onFile(file);
      }}
      className={`relative cursor-pointer rounded-xl border-2 border-dashed p-4 text-center transition-all ${
        dragOver
          ? 'scale-[1.01] border-neon bg-neon/10'
          : 'border-cream/20 bg-night/60 hover:border-neon/50 hover:bg-neon/5'
      }`}
    >
      <input
        ref={inputRef}
        type="file"
        accept="image/png,image/jpeg,image/heic,image/heif,.png,.jpg,.jpeg,.heic,.heif"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) onFile(file);
          e.target.value = '';
        }}
      />

      {busy ? (
        <div className="py-6">
          <p className="animate-pulse font-mono text-sm text-neon">{busy}</p>
          <p className="mt-1 font-mono text-[11px] text-cream/40">
            stays on your device — nothing is uploaded
          </p>
        </div>
      ) : photo ? (
        <div className="flex items-center gap-3 text-left">
          <img
            src={photo.url}
            alt="Uploaded photo preview"
            className="h-14 w-14 shrink-0 rounded-lg object-cover ring-1 ring-neon/60"
          />
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium text-cream/90">{photo.name}</p>
            <p className="font-mono text-[11px] text-cream/40">
              {photo.heic ? 'converted from HEIC' : 'ready to frame'} · click to replace
            </p>
          </div>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onRemove();
            }}
            className="shrink-0 rounded-md border border-cream/15 px-2.5 py-1.5 font-mono text-[11px] text-cream/60 transition hover:border-neon/60 hover:text-neon"
          >
            remove
          </button>
        </div>
      ) : (
        <div className="py-4">
          <div className="mx-auto mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-neon/15 text-lg text-neon ring-1 ring-neon/30">
            ⇪
          </div>
          <p className="text-sm font-medium text-cream/80">Drop your photo here</p>
          <p className="mt-1 font-mono text-[11px] text-cream/40">
            PNG · JPG · HEIC auto-converted · under 12MB
          </p>
        </div>
      )}
    </div>
  );
}
