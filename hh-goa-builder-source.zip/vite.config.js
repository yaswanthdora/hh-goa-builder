import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base: './' keeps every asset path relative, so the built app works when
// hosted under a sub-path such as https://<user>.github.io/<repo>/ (GitHub Pages).
export default defineConfig({
  base: './',
  plugins: [react()],
  build: {
    outDir: 'dist',
    sourcemap: false,
    // heic2any embeds the libheif WASM (~1.3 MB) and is code-split into its
    // own lazy chunk, so the main bundle stays small; don't warn about it.
    chunkSizeWarningLimit: 1600,
  },
});
