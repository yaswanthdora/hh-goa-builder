/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        forest: { DEFAULT: '#0F382C', deep: '#071A12', bright: '#0C5D32' },
        neon: { DEFAULT: '#FF007A', soft: '#FF5CA8' },
        cream: { DEFAULT: '#FFF9E6' },
        night: { DEFAULT: '#0D1117', panel: '#161B22' },
        goa: { yellow: '#FFD400', lime: '#D4FF00' },
      },
      fontFamily: {
        sans: ['"Space Grotesk"', 'system-ui', '-apple-system', 'Segoe UI', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
        display: ['"Fraunces"', 'Georgia', 'serif'],
        deva: ['"Yatra One"', '"Kalam"', 'sans-serif'],
      },
      boxShadow: {
        'neon-glow': '0 0 24px rgba(255, 0, 122, 0.35)',
        'neon-glow-lg': '0 0 48px rgba(255, 0, 122, 0.55)',
      },
    },
  },
  plugins: [],
};
