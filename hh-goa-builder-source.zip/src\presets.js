/**
 * Curated card-style presets.
 *
 * Each preset combines:
 *  - `art`:      which frame artwork variant to use ('classic' | 'sunset' | 'minimal')
 *  - `accent`:   primary accent color (injected into the SVG frames + canvas text/glow)
 *  - `accentSoft`: lighter accent used in gradients
 *  - `nameFont`: font for the full name (loaded via Google Fonts)
 *  - `monoFont`: font for role / builder title / chips
 *  - `bgTop` / `bgBottom`: base gradient behind the photo
 *  - `circle`: circular photo crop geometry ('ppf' | 'poster')
 *  - `light`: light (cream poster) theme — forest text on cream instead of
 *    cream-on-dark
 */
export const PRESETS = [
  {
    id: 'hh-goa-ppf',
    name: 'HH Goa PPF',
    tagline: 'Official circle frame',
    art: 'ppf',
    circle: 'ppf',
    accent: '#FF007A',
    accentSoft: '#FF5CA8',
    nameFont: 'Fraunces',
    monoFont: 'JetBrains Mono',
    bgTop: '#0F382C',
    bgBottom: '#071A12',
  },
  {
    id: 'poster-goa',
    name: 'Poster Goa',
    tagline: 'Cream tropical poster',
    art: 'poster',
    circle: 'poster',
    light: true,
    accent: '#DD3366',
    accentSoft: '#EE8899',
    nameFont: 'Fraunces',
    monoFont: 'JetBrains Mono',
    bgTop: '#F5E7C9',
    bgBottom: '#EBD3A8',
  },
  {
    id: 'hh-neon',
    name: 'HH Neon',
    tagline: 'Signature pink on forest',
    art: 'classic',
    accent: '#FF007A',
    accentSoft: '#FF5CA8',
    nameFont: 'Space Grotesk',
    monoFont: 'JetBrains Mono',
    bgTop: '#0F382C',
    bgBottom: '#0A241B',
  },
  {
    id: 'goa-sunset',
    name: 'Goa Sunset',
    tagline: 'Golden hour beach',
    art: 'sunset',
    accent: '#FF6B1A',
    accentSoft: '#FFB03A',
    nameFont: 'Space Grotesk',
    monoFont: 'Space Mono',
    bgTop: '#2E1B0E',
    bgBottom: '#170B04',
  },
  {
    id: 'tropic-green',
    name: 'Tropic Green',
    tagline: 'Neon jungle',
    art: 'classic',
    accent: '#22FF88',
    accentSoft: '#7CFFB2',
    nameFont: 'Orbitron',
    monoFont: 'Share Tech Mono',
    bgTop: '#0F382C',
    bgBottom: '#062A1E',
  },
  {
    id: 'neo-tokyo',
    name: 'Neo Tokyo',
    tagline: 'Electric purple night',
    art: 'classic',
    accent: '#B14EFF',
    accentSoft: '#D9A0FF',
    nameFont: 'Chakra Petch',
    monoFont: 'JetBrains Mono',
    bgTop: '#1B1030',
    bgBottom: '#0B0618',
  },
  {
    id: 'ocean-club',
    name: 'Ocean Club',
    tagline: 'Deep cyan water',
    art: 'sunset',
    accent: '#00E5FF',
    accentSoft: '#7FF0FF',
    nameFont: 'Space Grotesk',
    monoFont: 'Space Mono',
    bgTop: '#0B2A33',
    bgBottom: '#04161B',
  },
  {
    id: 'minimal-mono',
    name: 'Minimal Mono',
    tagline: 'Clean & terminal',
    art: 'minimal',
    accent: '#CCFF33',
    accentSoft: '#E8FF99',
    nameFont: 'Chakra Petch',
    monoFont: 'Share Tech Mono',
    bgTop: '#0F382C',
    bgBottom: '#062A1E',
  },
];
