import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import UploadZone from './components/UploadZone';
import { FORMATS, clamp, loadImage, renderBuilderCard } from './lib/renderer';
import {
  DEFAULT_NAME,
  DEFAULT_ROLE,
  DEFAULT_TITLE,
  MAX_ZOOM,
  MIN_ZOOM,
  PAN_LIMIT,
  SHARE_TEXT,
  SITE_URL,
} from './config';
import { PRESETS } from './presets';
import { buildPresetFrames } from './lib/frames';
import { lighten, darken } from './lib/color';

function Panel({ title, subtitle, right, children }) {
  return (
    <section className="rounded-2xl border border-cream/10 bg-panel/80 p-5 shadow-[0_1px_0_rgba(255,255,255,0.04)_inset,0_18px_50px_rgba(0,0,0,0.45)] backdrop-blur">
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <h2 className="text-[13px] font-bold uppercase tracking-[0.22em] text-cream/90">{title}</h2>
          {subtitle && <p className="mt-1 font-mono text-[11px] text-cream/40">{subtitle}</p>}
        </div>
        {right}
      </div>
      {children}
    </section>
  );
}

function TextField({ label, value, onChange, placeholder }) {
  return (
    <label className="block">
      <span className="font-mono text-[11px] uppercase tracking-[0.18em] text-neon">{label}</span>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="mt-1.5 w-full rounded-lg border border-cream/15 bg-night/90 px-3.5 py-2.5 text-sm text-cream outline-none transition placeholder:text-cream/25 focus:border-neon/70 focus:shadow-[0_0_0_3px_rgba(255,0,122,0.15)]"
      />
    </label>
  );
}

function Slider({ label, value, min, max, step = 0.01, onChange, display }) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between">
        <span className="font-mono text-[11px] uppercase tracking-[0.18em] text-cream/60">{label}</span>
        <span className="font-mono text-xs text-neon">{display}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        style={{ '--fill': `${pct}%` }}
      />
    </div>
  );
}

function ColorField({ label, value, onChange }) {
  return (
    <label className="block">
      <span className="font-mono text-[11px] uppercase tracking-[0.18em] text-cream/60">{label}</span>
      <span className="mt-1.5 flex items-center gap-2 rounded-lg border border-cream/15 bg-night/90 px-2.5 py-2">
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="h-7 w-9 cursor-pointer rounded border-0 bg-transparent p-0"
        />
        <span className="font-mono text-xs uppercase text-cream/70">{value}</span>
      </span>
    </label>
  );
}

function Toggle({ label, active, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex items-center gap-2 rounded-full border px-3 py-1.5 font-mono text-[11px] transition ${
        active
          ? 'border-neon/60 bg-neon/10 text-neon'
          : 'border-cream/20 text-cream/50 hover:border-cream/40'
      }`}
    >
      <span
        className={`h-2 w-2 rounded-full ${
          active ? 'bg-neon shadow-[0_0_8px_rgba(255,0,122,0.9)]' : 'bg-cream/25'
        }`}
      />
      {label}
    </button>
  );
}

export default function App() {
  const canvasRef = useRef(null);
  const wrapRef = useRef(null);
  const frameInputRef = useRef(null);
  const dragRef = useRef(null);
  const pendingPanRef = useRef({ x: 0, y: 0 });
  const rafRef = useRef(0);
  const toastTimerRef = useRef(null);
  const liveFramesRef = useRef(null);

  const [format, setFormat] = useState('square');
  const [photo, setPhoto] = useState(null);
  const [customFrame, setCustomFrame] = useState(null);
  const [presetId, setPresetId] = useState(PRESETS[0].id);
  const [frameCache, setFrameCache] = useState({});
  // null = use the preset's value; set = custom override
  const [styleOverrides, setStyleOverrides] = useState({ accent: null, bg: null });
  const [toggles, setToggles] = useState({ badge: true, waves: true, tagline: true });
  const [liveFrames, setLiveFrames] = useState({ square: null, card: null });
  const [qrEnabled, setQrEnabled] = useState(false);
  const [qrImage, setQrImage] = useState(null);
  const [name, setName] = useState(DEFAULT_NAME);
  const [role, setRole] = useState(DEFAULT_ROLE);
  const [title, setTitle] = useState(DEFAULT_TITLE);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [dragging, setDragging] = useState(false);
  const [busy, setBusy] = useState(null);
  const [toast, setToast] = useState(null);

  const showToast = useCallback((msg) => {
    setToast(msg);
    clearTimeout(toastTimerRef.current);
    toastTimerRef.current = setTimeout(() => setToast(null), 2600);
  }, []);

  // Build all preset frames once (accent-injected SVG artwork per preset).
  useEffect(() => {
    let alive = true;
    const urls = [];
    Promise.all(PRESETS.map((p) => buildPresetFrames(p)))
      .then((results) => {
        results.forEach((r) => {
          [r.square.url, r.card.url].forEach((u) => u && urls.push(u));
        });
        if (!alive) {
          urls.forEach(URL.revokeObjectURL);
          return;
        }
        const cache = {};
        results.forEach((r, i) => {
          cache[PRESETS[i].id] = r;
        });
        setFrameCache(cache);
      })
      .catch(() => urls.forEach(URL.revokeObjectURL));
    return () => {
      alive = false;
      urls.forEach(URL.revokeObjectURL);
    };
  }, []);

  // Generate the QR code lazily (module + image only when the toggle is on).
  useEffect(() => {
    if (!qrEnabled) return;
    let alive = true;
    (async () => {
      try {
        const { default: QRCode } = await import('qrcode');
        const url = await QRCode.toDataURL(SITE_URL, {
          errorCorrectionLevel: 'M',
          margin: 3,
          width: 480,
          color: { dark: '#0D1117', light: '#FFF9E6' },
        });
        const img = await loadImage(url);
        if (alive) setQrImage(img);
      } catch {
        // QR unavailable — the card simply renders without it
      }
    })();
    return () => {
      alive = false;
    };
  }, [qrEnabled]);

  // Keep the latest live frame URLs reachable for unmount cleanup.
  useEffect(() => {
    liveFramesRef.current = liveFrames;
  }, [liveFrames]);

  // Revoke object URLs on unmount.
  useEffect(
    () => () => {
      if (photo?.url) URL.revokeObjectURL(photo.url);
      if (customFrame?.url) URL.revokeObjectURL(customFrame.url);
      const live = liveFramesRef.current;
      [live?.square?.url, live?.card?.url].forEach((u) => u && URL.revokeObjectURL(u));
    },
    [] // eslint-disable-line react-hooks/exhaustive-deps
  );

  const f = FORMATS[format];
  const preset = PRESETS.find((p) => p.id === presetId) || PRESETS[0];

  // Effective style = preset values, with optional custom overrides.
  const accent = styleOverrides.accent ?? preset.accent;
  const accentSoft = styleOverrides.accent ? lighten(styleOverrides.accent) : preset.accentSoft;
  const bgTop = styleOverrides.bg ?? preset.bgTop;
  const bgBottom = styleOverrides.bg ? darken(styleOverrides.bg) : preset.bgBottom;
  const theme = useMemo(
    () => ({
      accent,
      accentSoft,
      nameFont: preset.nameFont,
      monoFont: preset.monoFont,
      bgTop,
      bgBottom,
      light: !!preset.light,
    }),
    [accent, accentSoft, bgTop, bgBottom, preset]
  );

  // Rebuild the live frame artwork whenever the style changes (debounced so
  // dragging a color picker doesn't thrash).
  useEffect(() => {
    let alive = true;
    const timer = setTimeout(() => {
      buildPresetFrames(preset, { accent, accentSoft, toggles })
        .then((frames) => {
          if (!alive) {
            [frames.square.url, frames.card.url].forEach((u) => u && URL.revokeObjectURL(u));
            return;
          }
          setLiveFrames((prev) => {
            [prev?.square?.url, prev?.card?.url].forEach((u) => u && URL.revokeObjectURL(u));
            return frames;
          });
        })
        .catch(() => {
          // keep the previous frames on failure
        });
    }, 120);
    return () => {
      alive = false;
      clearTimeout(timer);
    };
  }, [preset, accent, accentSoft, toggles.badge, toggles.waves, toggles.tagline]);

  // Full-resolution render — the canvas stays at export size and is scaled
  // down with CSS, so preview === download.
  const render = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    if (canvas.width !== f.width) canvas.width = f.width;
    if (canvas.height !== f.height) canvas.height = f.height;
    const ctx = canvas.getContext('2d');
    renderBuilderCard(ctx, {
      format: f,
      image: photo?.img ?? null,
      frameImage: customFrame?.img ?? liveFrames[format]?.img ?? null,
      name,
      role,
      title,
      zoom,
      panX: pan.x,
      panY: pan.y,
      theme,
      qrImage,
      qrEnabled,
      crop: preset.circle ? 'circle' : 'cover',
      circleKey: preset.circle,
    });
  }, [format, f, photo, customFrame, liveFrames, name, role, title, zoom, pan, theme, qrImage, qrEnabled, preset]);

  useEffect(() => {
    render();
  }, [render]);

  // Re-render once the webfonts are ready so canvas text uses them.
  useEffect(() => {
    let alive = true;
    const fonts = document.fonts;
    if (fonts?.load) {
      const loads = [];
      PRESETS.forEach((p) => {
        loads.push(fonts.load(`700 76px "${p.nameFont}"`));
        loads.push(fonts.load(`500 34px "${p.monoFont}"`));
        loads.push(fonts.load(`600 30px "${p.monoFont}"`));
      });
      // Devanagari logo + serif display used in the header and PPF frames
      loads.push(fonts.load('400 76px "Yatra One"'));
      loads.push(fonts.load('900 76px "Fraunces"'));
      Promise.all(loads).finally(() => {
        if (alive) render();
      });
    }
    return () => {
      alive = false;
    };
  }, [render]);

  // Wheel zoom — attached natively so preventDefault() works (React wheel
  // listeners are passive by default).
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const onWheel = (e) => {
      e.preventDefault();
      const dir = e.deltaY > 0 ? -1 : 1;
      setZoom((z) => clamp(+(z + dir * 0.06).toFixed(2), MIN_ZOOM, MAX_ZOOM));
    };
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, []);

  // ---- photo handling (incl. client-side HEIC conversion) ----
  const handleFile = useCallback(
    async (file) => {
      if (!file || busy) return;
      if (
        !/\.(png|jpe?g|heic|heif)$/i.test(file.name) &&
        !/image\/(png|jpe?g|heic|heif)/.test(file.type)
      ) {
        showToast('Please choose a PNG, JPG or HEIC photo.');
        return;
      }
      if (file.size > 12 * 1024 * 1024) {
        showToast('That file is a bit large — try under 12MB.');
        return;
      }
      const isHeic = /\.(heic|heif)$/i.test(file.name) || file.type.includes('heic');
      let url = null;
      try {
        if (isHeic) {
          setBusy('Converting HEIC…');
          // heic2any ships a large WASM build — load it only when needed
          const { default: heic2any } = await import('heic2any');
          const out = await heic2any({ blob: file, toType: 'image/png', quality: 1 });
          const blob = Array.isArray(out) ? out[0] : out;
          url = URL.createObjectURL(blob);
        } else {
          url = URL.createObjectURL(file);
        }
        const img = await loadImage(url);
        setPhoto((prev) => {
          if (prev?.url) URL.revokeObjectURL(prev.url);
          return { url, img, name: file.name, heic: isHeic };
        });
        setZoom(1);
        setPan({ x: 0, y: 0 });
        showToast('Photo loaded — drag it inside the frame!');
      } catch (err) {
        if (url) URL.revokeObjectURL(url);
        showToast(isHeic ? 'HEIC conversion failed — try PNG or JPG.' : 'Could not load that image.');
      } finally {
        setBusy(null);
      }
    },
    [busy, showToast]
  );

  const removePhoto = useCallback(() => {
    setPhoto((prev) => {
      if (prev?.url) URL.revokeObjectURL(prev.url);
      return null;
    });
    setZoom(1);
    setPan({ x: 0, y: 0 });
  }, []);

  // ---- custom frame overlay upload ----
  const handleFrameFile = useCallback(
    async (file) => {
      if (!file) return;
      if (!/\.(png|jpe?g|svg|webp)$/i.test(file.name)) {
        showToast('Frame must be PNG, JPG, SVG or WEBP.');
        return;
      }
      const url = URL.createObjectURL(file);
      try {
        const img = await loadImage(url);
        setCustomFrame((prev) => {
          if (prev?.url) URL.revokeObjectURL(prev.url);
          return { url, img, name: file.name };
        });
        showToast('Custom overlay active ✦');
      } catch {
        URL.revokeObjectURL(url);
        showToast('Could not load that frame.');
      }
    },
    [showToast]
  );

  const removeCustomFrame = useCallback(() => {
    setCustomFrame((prev) => {
      if (prev?.url) URL.revokeObjectURL(prev.url);
      return null;
    });
    showToast('Back to the built-in HH Goa frames.');
  }, [showToast]);

  // ---- drag-to-pan on the canvas (throttled to one redraw per frame) ----
  const onPointerDown = (e) => {
    if (e.button !== 0 && e.pointerType === 'mouse') return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.setPointerCapture(e.pointerId);
    const rect = canvas.getBoundingClientRect();
    dragRef.current = {
      id: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      panStart: { x: pan.x, y: pan.y },
      scale: canvas.width / rect.width,
    };
    setDragging(true);
  };

  const onPointerMove = (e) => {
    const d = dragRef.current;
    if (!d || e.pointerId !== d.id) return;
    pendingPanRef.current = {
      x: clamp(d.panStart.x + (e.clientX - d.startX) * d.scale, -PAN_LIMIT, PAN_LIMIT),
      y: clamp(d.panStart.y + (e.clientY - d.startY) * d.scale, -PAN_LIMIT, PAN_LIMIT),
    };
    if (!rafRef.current) {
      rafRef.current = requestAnimationFrame(() => {
        rafRef.current = 0;
        setPan(pendingPanRef.current);
      });
    }
  };

  const endDrag = (e) => {
    const d = dragRef.current;
    if (d && e.pointerId === d.id) dragRef.current = null;
    setDragging(false);
  };

  // ---- actions ----
  const handleDownload = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const a = document.createElement('a');
    a.download = 'hh-goa-builder.png';
    a.href = canvas.toDataURL('image/png');
    a.click();
    showToast('PNG saved — #FrameInGoa!');
  }, [showToast]);

  const handleCopy = useCallback(async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    try {
      const blob = await new Promise((resolve, reject) => {
        canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('toBlob failed'))), 'image/png');
      });
      if (!navigator.clipboard?.write) throw new Error('clipboard unsupported');
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
      showToast('Copied to clipboard!');
    } catch {
      showToast('Copy not supported here — use Download instead.');
    }
  }, [showToast]);

  const handleShare = useCallback(() => {
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(
      SHARE_TEXT
    )}&url=${encodeURIComponent(SITE_URL)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  }, []);

  return (
    <div className="min-h-screen bg-night text-cream">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-cream/10 bg-night/85 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-4 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-goa-yellow font-display text-lg font-black text-night shadow-[0_0_24px_rgba(255,212,0,0.35)] ring-2 ring-neon/50">
              HH
            </div>
            <div>
              <h1 className="font-display text-lg font-black leading-tight tracking-wide sm:text-xl">
                HACKER HOUSE{' '}
                <span className="font-deva text-[1.35em] font-normal text-neon drop-shadow-[0_0_10px_rgba(255,0,122,0.7)]">
                  गोवा
                </span>{' '}
                2026
              </h1>
              <p className="font-mono text-[11px] tracking-widest text-cream/45">
                BUILDER ID GENERATOR · FRAME IN GOA
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="hidden rounded-full border border-goa-yellow/40 bg-goa-yellow/10 px-3 py-1 font-mono text-[11px] text-goa-yellow sm:block">
              OCT 29 – 31, 2026 · GOA, INDIA
            </span>
            <span className="hidden rounded-full border border-cream/15 px-3 py-1 font-mono text-[11px] text-cream/40 lg:block">
              2:47 PM STUDIO
            </span>
          </div>
        </div>
      </header>

      <main className="mx-auto grid max-w-7xl gap-8 px-4 py-8 sm:px-6 lg:grid-cols-[400px_minmax(0,1fr)]">
        {/* Controls */}
        <div className="space-y-5">
          <Panel title="01 · Your Photo" subtitle="PNG · JPG · HEIC — converted in your browser">
            <UploadZone photo={photo} busy={busy} onFile={handleFile} onRemove={removePhoto} />
          </Panel>

          <Panel title="02 · Builder Details" subtitle="Rendered live onto the card">
            <div className="space-y-4">
              <TextField label="Full Name" value={name} onChange={setName} placeholder="e.g. Ada Lovelace" />
              <TextField label="Role / Stack" value={role} onChange={setRole} placeholder="e.g. AI Engineer" />
              <TextField label="Builder Title" value={title} onChange={setTitle} placeholder="e.g. 10x Hacker" />
            </div>
          </Panel>

          <Panel title="03 · Card Format" subtitle="Choose your canvas">
            <div className="grid grid-cols-2 gap-3">
              {Object.values(FORMATS).map((fm) => {
                const active = format === fm.key;
                return (
                  <button
                    key={fm.key}
                    type="button"
                    onClick={() => setFormat(fm.key)}
                    className={`rounded-xl border p-3 text-left transition ${
                      active
                        ? 'border-neon bg-neon/10 shadow-[0_0_20px_rgba(255,0,122,0.25)]'
                        : 'border-cream/15 bg-night/70 hover:border-cream/40'
                    }`}
                  >
                    <span
                      className={`mb-2 block rounded border-2 ${active ? 'border-neon' : 'border-cream/40'}`}
                      style={{ width: fm.key === 'square' ? 46 : 66, aspectRatio: `${fm.width} / ${fm.height}` }}
                    />
                    <span className="block text-sm font-semibold">{fm.label}</span>
                    <span className="block font-mono text-[11px] text-cream/45">
                      {fm.width}×{fm.height}
                    </span>
                  </button>
                );
              })}
            </div>
          </Panel>

          <Panel title="04 · Adjust Photo" subtitle="Pan & zoom inside the frame">
            <div className="space-y-5">
              <Slider
                label="Zoom"
                value={zoom}
                min={MIN_ZOOM}
                max={MAX_ZOOM}
                step={0.01}
                onChange={setZoom}
                display={`${zoom.toFixed(2)}×`}
              />
              <Slider
                label="Position X"
                value={pan.x}
                min={-PAN_LIMIT}
                max={PAN_LIMIT}
                step={1}
                onChange={(v) => setPan((p) => ({ ...p, x: v }))}
                display={`${Math.round(pan.x)} px`}
              />
              <Slider
                label="Position Y"
                value={pan.y}
                min={-PAN_LIMIT}
                max={PAN_LIMIT}
                step={1}
                onChange={(v) => setPan((p) => ({ ...p, y: v }))}
                display={`${Math.round(pan.y)} px`}
              />
              <button
                type="button"
                onClick={() => {
                  setPan({ x: 0, y: 0 });
                  setZoom(1);
                }}
                className="w-full rounded-lg border border-cream/15 py-2 font-mono text-xs text-cream/60 transition hover:border-neon/50 hover:text-neon"
              >
                ↺ RESET POSITION & ZOOM
              </button>
            </div>
          </Panel>

          <Panel title="05 · Card Style" subtitle="Curated presets — accent, fonts & frame art">
            <div className="grid grid-cols-3 gap-2.5">
              {PRESETS.map((p) => {
                const active = presetId === p.id;
                const thumb = frameCache[p.id]?.square;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setPresetId(p.id)}
                    className={`group relative overflow-hidden rounded-xl border text-left transition ${
                      active ? '' : 'border-cream/15 hover:border-cream/40'
                    }`}
                    style={
                      active
                        ? { borderColor: p.accent, boxShadow: `0 0 18px ${p.accent}55` }
                        : undefined
                    }
                  >
                    {thumb ? (
                      <img
                        src={thumb.url}
                        alt={`${p.name} preset preview`}
                        className="aspect-square w-full object-cover"
                      />
                    ) : (
                      <div className="aspect-square w-full animate-pulse bg-night/60" />
                    )}
                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 to-transparent px-2 pb-1.5 pt-6">
                      <p
                        className="text-[11px] font-bold leading-tight"
                        style={{ fontFamily: `"${p.nameFont}", sans-serif` }}
                      >
                        {p.name}
                      </p>
                      <p className="mt-0.5 font-mono text-[9px] leading-tight text-cream/55">
                        {p.tagline}
                      </p>
                    </div>
                    {active && (
                      <span
                        className="absolute right-1.5 top-1.5 flex h-4 w-4 items-center justify-center rounded-full text-[10px] font-bold text-night"
                        style={{ background: p.accent }}
                      >
                        ✓
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
            <div className="mt-3 flex items-center gap-2">
              <button
                type="button"
                onClick={() => frameInputRef.current?.click()}
                className="flex-1 rounded-lg border border-dashed border-cream/25 px-3 py-2 font-mono text-xs text-cream/60 transition hover:border-neon/60 hover:text-neon"
              >
                ⤒ Upload custom frame
              </button>
              {customFrame && (
                <button
                  type="button"
                  onClick={removeCustomFrame}
                  className="rounded-lg border border-neon/40 px-3 py-2 font-mono text-xs text-neon transition hover:bg-neon/10"
                  title="Remove custom frame"
                >
                  ✕
                </button>
              )}
            </div>
            <input
              ref={frameInputRef}
              type="file"
              accept=".png,.jpg,.jpeg,.svg,.webp,image/png,image/jpeg,image/svg+xml,image/webp"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleFrameFile(file);
                e.target.value = '';
              }}
            />
            {customFrame && (
              <p className="mt-2 font-mono text-[11px] text-neon/80">✦ using {customFrame.name}</p>
            )}
          </Panel>

          <Panel title="06 · Customize" subtitle="Tweak the accent, background & frame parts">
            <div className="space-y-5">
              <div className="grid grid-cols-2 gap-3">
                <ColorField
                  label="Accent"
                  value={accent}
                  onChange={(c) => setStyleOverrides((o) => ({ ...o, accent: c }))}
                />
                <ColorField
                  label="Background"
                  value={bgTop}
                  onChange={(c) => setStyleOverrides((o) => ({ ...o, bg: c }))}
                />
              </div>
              <div>
                <p className="mb-2 font-mono text-[11px] uppercase tracking-[0.18em] text-cream/60">
                  Frame elements
                </p>
                <div className="flex flex-wrap gap-2">
                  <Toggle
                    label="Badge"
                    active={toggles.badge}
                    onClick={() => setToggles((t) => ({ ...t, badge: !t.badge }))}
                  />
                  <Toggle
                    label="Waves"
                    active={toggles.waves}
                    onClick={() => setToggles((t) => ({ ...t, waves: !t.waves }))}
                  />
                  <Toggle
                    label="Tagline"
                    active={toggles.tagline}
                    onClick={() => setToggles((t) => ({ ...t, tagline: !t.tagline }))}
                  />
                </div>
              </div>
              <div>
                <p className="mb-2 font-mono text-[11px] uppercase tracking-[0.18em] text-cream/60">
                  Card extras
                </p>
                <div className="flex flex-wrap gap-2">
                  <Toggle
                    label="QR Code"
                    active={qrEnabled}
                    onClick={() => setQrEnabled((v) => !v)}
                  />
                </div>
                <p className="mt-1.5 font-mono text-[10px] text-cream/35">
                  Encodes the live site URL · shown on the ID card format
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setStyleOverrides({ accent: null, bg: null });
                  setToggles({ badge: true, waves: true, tagline: true });
                  setQrEnabled(false);
                  showToast('Style reset to the preset.');
                }}
                className="w-full rounded-lg border border-cream/15 py-2 font-mono text-xs text-cream/60 transition hover:border-neon/50 hover:text-neon"
              >
                ↺ RESET STYLE TO PRESET
              </button>
              {customFrame && (
                <p className="font-mono text-[11px] text-cream/40">
                  A custom overlay replaces the frame art — toggles apply to the preset frames.
                </p>
              )}
            </div>
          </Panel>
        </div>

        {/* Preview + actions */}
        <div className="space-y-4 lg:sticky lg:top-20 lg:self-start">
          <Panel
            title="Live Preview"
            subtitle={`${f.width} × ${f.height} px · exports at full resolution`}
            right={
              <span className="rounded-full border border-neon/40 bg-neon/10 px-2.5 py-1 font-mono text-[10px] tracking-widest text-neon">
                {f.key === 'square' ? 'SQUARE · 1:1' : 'CARD · 1200×630'}
              </span>
            }
          >
            <div ref={wrapRef} className="relative mx-auto w-full" style={{ aspectRatio: `${f.width} / ${f.height}` }}>
              <canvas
                ref={canvasRef}
                className="builder-canvas absolute inset-0 h-full w-full rounded-2xl"
                onPointerDown={onPointerDown}
                onPointerMove={onPointerMove}
                onPointerUp={endDrag}
                onPointerCancel={endDrag}
              />
              <div className="pointer-events-none absolute inset-0 rounded-2xl shadow-[0_0_44px_rgba(255,0,122,0.22)] ring-1 ring-neon/40" />
            </div>
            <p className="mt-3 text-center font-mono text-[11px] text-cream/40">
              Drag on the canvas to reposition · scroll wheel or slider to zoom
            </p>
          </Panel>

          <div className="grid gap-3 sm:grid-cols-2">
            <button
              type="button"
              onClick={handleDownload}
              className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-neon to-neon-soft px-4 py-3.5 text-sm font-bold text-cream shadow-[0_0_28px_rgba(255,0,122,0.4)] transition hover:scale-[1.02] hover:shadow-[0_0_46px_rgba(255,0,122,0.65)] active:scale-[0.98]"
            >
              <span aria-hidden="true">⬇</span> Download PNG
            </button>
            <button
              type="button"
              onClick={handleShare}
              className="flex items-center justify-center gap-2 rounded-xl border border-cream/20 bg-night/70 px-4 py-3.5 text-sm font-bold text-cream transition hover:border-neon/60 hover:text-neon hover:shadow-[0_0_24px_rgba(255,0,122,0.3)]"
            >
              <span aria-hidden="true" className="font-sans">
                𝕏
              </span>{' '}
              Share to X
            </button>
          </div>
          <button
            type="button"
            onClick={handleCopy}
            className="w-full rounded-xl border border-cream/15 py-2.5 font-mono text-xs text-cream/55 transition hover:border-neon/40 hover:text-neon"
          >
            ⧉ Copy PNG to clipboard
          </button>
        </div>
      </main>

      <footer className="border-t border-cream/10 py-6 text-center">
        <p className="font-mono text-[11px] tracking-widest text-cream/35">
          <span className="text-goa-yellow">2:47 PM STUDIO</span> ·{' '}
          <span className="text-neon">HACKER HOUSE GOA 2026</span> · BUILT IN GOA — SHIP FROM PARADISE ·{' '}
          <span className="font-deva text-neon">गोवा</span>
        </p>
      </footer>

      {toast && (
        <div className="fixed bottom-6 left-1/2 z-50 -translate-x-1/2 whitespace-nowrap rounded-full border border-neon/40 bg-night/95 px-5 py-2.5 text-sm text-cream shadow-[0_0_28px_rgba(255,0,122,0.4)]">
          {toast}
        </div>
      )}
    </div>
  );
}
