// Site-level configuration. Update SITE_URL to your deployed GitHub Pages
// URL so the "Share to X" intent links to the live app.
export const SITE_URL = 'https://myaswanthdora.github.io/hh-goa-builder/';

export const SHARE_TEXT =
  'Just generated my HH Goa 2026 Builder Card! Check it out #FrameInGoa';

export const DEFAULT_NAME = 'Your Name';
export const DEFAULT_ROLE = 'AI Engineer';
export const DEFAULT_TITLE = '10x Hacker';

export const MIN_ZOOM = 1;
export const MAX_ZOOM = 3;

// Pan range in canvas pixels. The renderer clamps further so the photo
// always covers the frame region.
export const PAN_LIMIT = 500;
